import Login from './screens/auth/Login';
import Register from './screens/auth/Register';

export {Login, Register};
