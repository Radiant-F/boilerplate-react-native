import {StyleSheet, Text, View, TextInput, Button} from 'react-native';
import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {fetchLogin} from '../../../redux/actions/auth';

export default function Login() {
  const dispatch = useDispatch();
  const {user_data} = useSelector(state => state.auth);
  // console.log(user_data);
  const [formData, setFormData] = useState({email: null, password: null});
  return (
    <View>
      <Text>Login</Text>
      <TextInput
        placeholder="email"
        onChangeText={input => setFormData({...formData, email: input})}
      />
      <TextInput
        placeholder="password"
        onChangeText={input => setFormData({...formData, password: input})}
      />
      <Button title="masuk" onPress={() => dispatch(fetchLogin(formData))} />
    </View>
  );
}

const styles = StyleSheet.create({});
