import {createSlice} from '@reduxjs/toolkit';
import {fetchLogin} from '../actions/auth';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user_data: null,
    is_login: true,
    status: 'idle',
  },
  reducers: {
    userData: (state, action) => {
      state.token = action.payload;
    },
    isLogin: (state, action) => {
      state.is_login = action.payload;
    },
  },
  extraReducers: {
    [fetchLogin.pending]: state => {
      state.status = 'loading';
    },
    [fetchLogin.fulfilled]: state => {
      state.status = 'idle';
    },
    [fetchLogin.rejected]: state => {
      state.status = 'error';
    },
  },
});

export const {isLogin, userData} = authSlice.actions;

export default authSlice.reducer;

// extraReducers: {
//   [fetchLogin.pending]: state => {},
//   [fetchLogin.fulfilled]: state => {},
//   [fetchLogin.rejected]: state => {},
// },
