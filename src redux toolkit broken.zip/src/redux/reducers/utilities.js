import {createSlice} from '@reduxjs/toolkit';

const utilsSlice = createSlice({
  name: 'utilities',
  initialState: {
    is_loading: false,
  },
  reducers: {
    isLoading: (state, {payload}) => {
      state.is_loading = payload;
    },
  },
});

export const {isLoading} = utilsSlice.actions;

export default utilsSlice.reducer;
