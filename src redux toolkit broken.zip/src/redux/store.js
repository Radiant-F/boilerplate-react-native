import {configureStore} from '@reduxjs/toolkit';
import auth from './reducers/auth';
import utilities from './reducers/utilities';

export const store = configureStore({
  reducer: {auth, utilities},
});
