import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

export default function Dashboard() {
  return (
    <View>
      <Text>Dashboard</Text>
    </View>
  );
}

const styles = StyleSheet.create({});
