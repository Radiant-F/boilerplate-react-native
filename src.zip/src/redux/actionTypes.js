const LOGIN = 'LOGIN';
const AUTH_TYPE = 'AUTH_TYPE';

export {LOGIN, AUTH_TYPE};
