import Auth from './Auth/Auth';
import Dashboard from './Dashboard/Dashboard';

export {Dashboard, Auth};
